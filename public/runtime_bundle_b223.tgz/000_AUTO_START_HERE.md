# v1326p15e2b223 AUTO START

最新正本は `v1326p15e2b223` / 通常運用名 `nobu.001`。

まだ計算・探索・シミュレーション・DB登録は開始しません。
まず相手編成を確認します。

確認項目:
- 兵種と兵種Lv
- 大将・副将・副将の3武将名
- 各武将の凸
- 各武将の固有戦法
- 各武将の装着戦法2枠

登録済み仮想敵を使う場合は、その名称だけで指定してください。
相手編成を確認した後に、その相手に対して何をするかを決めます。

A：新規最適編成探索
B：既存自軍編成の改善
C：既存編成同士の勝率確認
D：行動順・ログ精査

登録ゲート:
- この編成で完成としてよいですか？
- この対戦相手（仮想敵）を仮想敵DBに登録しますか？
- この提案自軍編成を自軍編成DBに登録しますか？

更新継承:
- v1326p15e2b218 / b218 現runtime再計算schema。
- v1326p15e2b219 / b219 左右入替 side-normalized balanced screen。
- v1326p15e2b220 / b220 hard legality preflight。
- v1326p15e2b221 / b221 formal queue。
- v1326p15e2b222 / b222 adoption recommender / 採用判断。
- v1326p15e2b223 / b223 主要既存カード現runtime再計算suite。

方針:
- 現runtime再計算のみ有効。
- b207以前の勝率・対戦結果は引用禁止。
- b223低試行レポートは provisional。正式勝率ではない。
- full formal 100x3 each direction 未満は採用判断不可。
- recommendationはDB登録ではない。登録確認は必ず別々に行う。

採用判断ラベル:
- FORMAL_ADOPT
- CONDITIONAL_ADOPT
- MATCHUP_SPECIFIC_ONLY
- REJECT
- NEEDS_FULL_100x3
